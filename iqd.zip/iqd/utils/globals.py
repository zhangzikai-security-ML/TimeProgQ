
# TODO change to context free implementation
global total_timestep
global current_timestep
global stored_timestep